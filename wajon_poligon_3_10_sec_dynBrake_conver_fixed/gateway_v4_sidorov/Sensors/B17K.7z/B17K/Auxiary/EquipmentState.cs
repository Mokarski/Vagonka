namespace Sensors.B17K
{
    internal enum EquipmentState
    {
        Stop = 0,
        Active = 1,
        Failure = 2
    }
}